package Modelo;

public enum EpocaHistorica {
   PRECOLOMBINA,
   COLONIAL,
   MODERNA
}
