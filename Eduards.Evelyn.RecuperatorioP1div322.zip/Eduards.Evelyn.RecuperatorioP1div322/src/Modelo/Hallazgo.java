package Modelo;

import java.time.LocalDate;

public abstract class Hallazgo {
    private static int CONTADOR = 50000;
    private final int id;
    private final String sitio;
    private final LocalDate fecha;
    private final int estadoConservacion;

    public Hallazgo(int id, String sitio, LocalDate fecha, int estadoConservacion) {
        validarSitio(sitio);
        validarFecha(fecha);
        validarEstado(estadoConservacion);
        
        this.id = CONTADOR++;
        this.sitio = sitio;
        this.fecha = fecha;
        this.estadoConservacion = estadoConservacion;
    }
    
    private void validarSitio(String sitio){
    if (sitio == null || sitio.equals("")) {
        throw new IllegalArgumentException("El sitio no puede estar vacío");
    }
    }
    
    private void validarFecha(LocalDate fecha){
        if (fecha == null) {
                throw new IllegalArgumentException("La fecha no puede ser nula");
        }
    }
    
    private void validarEstado(int estado){
     if (estado < 1 || estado > 10) {
            throw new IllegalArgumentException("El estado de conservación debe estar entre 1 y 10");
        }
    }

    public int getId() {
        return id;
    }

    public String getSitio() {
        return sitio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }

    @Override
    public String toString() {
        return "Hallazgo{" + "id=" + id +
                ", sitio=" + sitio +
                ", fecha=" + fecha +
                ", estadoConservacion=" +
                estadoConservacion + '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Hallazgo otro)) {
            return false;
        }
        return this.sitio.equals(otro.sitio) && this.fecha.equals(otro.fecha);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(sitio, fecha);
    }
    
}
    

