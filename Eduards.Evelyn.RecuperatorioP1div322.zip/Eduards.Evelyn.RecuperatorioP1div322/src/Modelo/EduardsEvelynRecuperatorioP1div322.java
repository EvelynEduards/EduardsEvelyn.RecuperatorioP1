package Modelo;

import Exception.HallazgoDuplicadoException;
import java.time.LocalDate;

public class EduardsEvelynRecuperatorioP1div322 {

    public static void main(String[] args) {
        GestionHallazgos gestion = new GestionHallazgos();

        // 1. Agregar hallazgos
        
        try {
            Fosil f = new Fosil(50000, "Argentina", LocalDate.of(2023, 5, 10), 7, "T-Rex", true);       
            gestion.agregarHallazgo(f);

            // Intento duplicado (mismo sitio y fecha)
            Fosil f2 = new Fosil(50000, "Argentina", LocalDate.of(2023, 5, 10), 7, "T-Rex", true);
            gestion.agregarHallazgo(f2);
        } catch (HallazgoDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            gestion.agregarHallazgo(new Fosil(50001, "Espania", LocalDate.of(2022, 7, 10), 5, "T-Rex", true));
            gestion.agregarHallazgo(new Herramienta(50002, "Peru",LocalDate.of(2022, 9, 20), 8, "Piedra", "Cortar"));
            gestion.agregarHallazgo(new Construccion(50003, "Brasil",LocalDate.of(2021, 1, 5), 4, "Templo", EpocaHistorica.PRECOLOMBINA));
            gestion.agregarHallazgo(new Construccion(50004, "EEUU",LocalDate.of(2021, 1, 6), 5, "Vivienda", EpocaHistorica.PRECOLOMBINA));
        } catch (HallazgoDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // 2. Mostrar hallazgos registrados
        System.out.println("\nListado de hallazgos:");
        gestion.mostrarHallazgos();

        // 3. Ejecutar análisis de laboratorio
        System.out.println("\nEjecutando análisis de laboratorio:");
        gestion.ejecutarAnalisis();

        // 4. Ejecutar restauración
        System.out.println("\nEjecutando restauracion:");
        gestion.ejecutarRestauracion();

        // 5. Filtrar por época histórica
        System.out.println("\nFiltrando hallazgos por epoca Precolombina:");
        gestion.filtrarPorEpoca(EpocaHistorica.PRECOLOMBINA);

        // 6. Filtrar por estado de conservación
        System.out.println("\nFiltrando hallazgos con estado de conservacion entre 5 y 8:");
        gestion.filtrarPorEstadoConservacion(5, 8);
    }
}
