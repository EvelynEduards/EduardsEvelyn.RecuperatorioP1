package Modelo;

import Interfaces.Analizable;
import java.time.LocalDate;

public class Herramienta extends Hallazgo implements Analizable{
    
    private String material;
    private String usoProbable;

    public Herramienta(int id, String sitio, LocalDate fecha, int estadoConservacion, String material, String usoProbable) {
        super(id, sitio, fecha, estadoConservacion);
        validarMaterial(material);
        validarUso(usoProbable);
        this.material = material;
        this.usoProbable = usoProbable;
    }
    
    private void validarMaterial(String material){
     if (material == null || material.equals("")) {
        throw new IllegalArgumentException("El material no puede estar vacío");
        }
    }
    
    private void validarUso(String uso){
      if(uso == null || uso.equals("")){
          throw new IllegalArgumentException("El uso probable no puede estar vacío");
      }
    }

    @Override
    public void analizar() {
        System.out.println("Analizando herramienta hallada en el sitio: " + getSitio());
    }
    
    @Override
    public String toString() {
        return super.toString()
               + " [Herramienta] Material: " + material
               + ", Uso probable: " + usoProbable;
    }
}
