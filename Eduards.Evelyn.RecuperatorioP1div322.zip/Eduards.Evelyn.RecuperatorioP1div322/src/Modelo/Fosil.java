package Modelo;

import Interfaces.Analizable;
import java.time.LocalDate;

public class Fosil extends Hallazgo implements Analizable {
   
    private String especie;
    private boolean esqueletoCompleto;

    public Fosil(int id, String sitio, LocalDate fecha, int estadoConservacion, String especie, boolean esqueletoCompleto) {
    super(id, sitio, fecha, estadoConservacion);
    this.especie = especie;
    this.esqueletoCompleto = esqueletoCompleto;
}

    
    private void validarEspecie(String especie){
    if(especie == null || especie.equals("")){
        throw new IllegalArgumentException("La especie no puede estar vacia");
        }
    }
    
    public boolean tieneEsqueletoCompleto(){
    return esqueletoCompleto;
    }
    

    @Override
    public void analizar() {
        System.out.println("Analizando fósil de especie " + especie + " del sitio " + getSitio()); 
    }
    
    @Override
    public String toString() {
        String completo = "No";
        if (esqueletoCompleto) {
            completo = "Sí";
        }

        return super.toString()
           + " Fosil: Especie: " + especie
           + ", Esqueleto completo: " + completo;
        }

    }

    

