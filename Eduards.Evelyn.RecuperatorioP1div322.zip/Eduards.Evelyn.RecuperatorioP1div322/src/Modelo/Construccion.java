package Modelo;

import Interfaces.Restaurable;
import java.time.LocalDate;

public class Construccion extends Hallazgo implements Restaurable {
    
    private String tipoEdificacion;
    private EpocaHistorica epocaHistorica;

    public Construccion(int id, String sitio, LocalDate fecha, int estadoConservacion,String tipoEdificacion, EpocaHistorica epocaHistorica) {
        super(id, sitio, fecha, estadoConservacion);
        validarTipoEdificacion(tipoEdificacion);
        validarEpocaHistorica(epocaHistorica);
        this.tipoEdificacion = tipoEdificacion;
        this.epocaHistorica = epocaHistorica;
    }
    
    private void validarTipoEdificacion(String tipo){
        if(tipo == null || tipo.equals("")){
        throw new IllegalArgumentException("El tipo de edificacion no puede estar vacio");
        }
    }
    
   private void validarEpocaHistorica(EpocaHistorica epoca){
        if(epoca == null){
        throw new IllegalArgumentException("La época histórica no puede ser nula");
        }
    }

    @Override
    public void restaurar() {
        System.out.println("Restaurando construcción: " + tipoEdificacion + " del sitio " + getSitio());
    }

    public EpocaHistorica getEpocaHistorica() {
        return epocaHistorica;
    }

    @Override
    public String toString() {
        return super.toString()
               + " [Construcción] Tipo de edificación: " + tipoEdificacion
               + ", Época histórica: " + epocaHistorica;
    }
    
   
    
}
