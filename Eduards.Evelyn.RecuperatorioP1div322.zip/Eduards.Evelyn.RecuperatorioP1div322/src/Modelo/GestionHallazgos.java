package Modelo;


import Exception.HallazgoDuplicadoException;
import Interfaces.Analizable;
import Interfaces.Restaurable;
import java.util.ArrayList;
import java.util.List;

public class GestionHallazgos {
    private List<Hallazgo> hallazgos;
    
    public GestionHallazgos(){
    hallazgos = new ArrayList<>();
    }
    
    private void validarHallazgo(Hallazgo h) throws HallazgoDuplicadoException {
        if (h == null) {
            throw new NullPointerException("No hay hallazgo para agregar");
        }
        if (hallazgos.contains(h)) { // usa equals para validar duplicados
            throw new HallazgoDuplicadoException();
        }
    }

    public void agregarHallazgo(Hallazgo h) throws HallazgoDuplicadoException {
        validarHallazgo(h);
        hallazgos.add(h);
    }

    private void validarHayHallazgos() {
        if (hallazgos.isEmpty()) {
            throw new IllegalStateException("No hay hallazgos registrados");
        }
    }

    public void mostrarHallazgos() {
        validarHayHallazgos();
        System.out.println("Listado de hallazgos:");
        for (Hallazgo h : hallazgos) {
            System.out.println(h);
        }
    }

    // Ejecutar análisis para los hallazgos que implementen la interfaz Analizable
    public void ejecutarAnalisis() {
        validarHayHallazgos();
        for (Hallazgo h : hallazgos) {
            if (h instanceof Analizable) {
                ((Analizable) h).analizar();
            } else {
                System.out.println("El hallazgo con ID " + h.getId() + " no puede ser analizado.");
            }
        }
    }

    // Ejecutar restauración para los hallazgos que implementen Restaurable
    public void ejecutarRestauracion() {
        validarHayHallazgos();
        for (Hallazgo h : hallazgos) {
            if (h instanceof Restaurable) {
                ((Restaurable) h).restaurar();
            } else {
                System.out.println("El hallazgo con ID " + h.getId() + " no puede ser restaurado.");
            }
        }
    }

    // Filtrar por época histórica (solo aplica a Construccion)
    public List<Hallazgo> filtrarPorEpoca(EpocaHistorica epoca) {
        validarHayHallazgos();
        List<Hallazgo> filtrados = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            if (h instanceof Construccion) {
                Construccion c = (Construccion) h;
                if (c.getEpocaHistorica() == epoca) {
                    filtrados.add(c);
                    System.out.println(c);
                }
            }
        }
        return filtrados;
    }

    // Mostrar hallazgos según rango de estado de conservación (inclusive)
    public List<Hallazgo> filtrarPorEstadoConservacion(int desde, int hasta) {
        validarHayHallazgos();
        if (desde < 1 || hasta > 10 || desde > hasta) {
            throw new IllegalArgumentException("Rango de estado inválido. Debe ser entre 1 y 10, y desde <= hasta.");
        }

        List<Hallazgo> filtrados = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            int estado = h.getEstadoConservacion();
            if (estado >= desde && estado <= hasta) {
                filtrados.add(h);
                System.out.println(h);
            }
        }
        return filtrados;
    }
}