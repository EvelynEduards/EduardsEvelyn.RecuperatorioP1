package Interfaces;

public interface Analizable {
    void analizar();
}
