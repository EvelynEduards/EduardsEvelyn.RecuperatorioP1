package Interfaces;

public interface Restaurable {
    void restaurar();
}
