package Exception;

public class HallazgoDuplicadoException extends Exception {
    
    private static final String MENSAJE = "Hallazgo duplicado";
   
    public HallazgoDuplicadoException() {
    super(MENSAJE);
    }

    
    public HallazgoDuplicadoException(String msg) {
        super(msg);
    }
}
